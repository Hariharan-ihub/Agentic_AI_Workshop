from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import os
import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import re
from dataclasses import dataclass
from sklearn.feature_extraction.text import TfidfVectorizer

@dataclass
class Document:
    page_content: str
    metadata: Dict[str, Any]

class VectorStore:
    def __init__(self, store_path: str = "vector_store.json"):
        self.store_path = store_path
        self.vectorizer = TfidfVectorizer(
            max_features=1000,
            stop_words='english',
            ngram_range=(1, 2),
            min_df=1,
            max_df=1.0  # Changed from 0.95 to 1.0 to allow all terms
        )
        # Initialize with empty data structure
        self.data = {"business_analyses": [], "risk_profiles": []}
        # Try to load existing data
        try:
            if os.path.exists(self.store_path):
                with open(self.store_path, 'r') as f:
                    loaded_data = json.load(f)
                    if isinstance(loaded_data, dict):
                        self.data = loaded_data
        except Exception as e:
            print(f"Error loading vector store: {e}")
            # If there's an error, we'll use the empty data structure
            pass
        
        # Fit vectorizer with initial data
        self._fit_vectorizer()
    
    def _load_store(self) -> Dict[str, Any]:
        if os.path.exists(self.store_path):
            with open(self.store_path, 'r') as f:
                return json.load(f)
        return {"business_analyses": [], "risk_profiles": []}
    
    def _save_store(self):
        with open(self.store_path, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    def _convert_existing_embeddings(self):
        """Convert existing embeddings to TF-IDF format."""
        # Collect all texts
        texts = []
        for item in self.data["business_analyses"]:
            texts.append(item["text"])
        for item in self.data["risk_profiles"]:
            texts.append(f"{item['domain']}_{item['geography']}")
        
        if texts:
            # Fit vectorizer on all texts
            self.vectorizer.fit(texts)
            
            # Convert business analyses
            for item in self.data["business_analyses"]:
                if "embedding" in item:
                    item["embedding"] = self._get_embedding(item["text"]).tolist()
            
            # Convert risk profiles
            for item in self.data["risk_profiles"]:
                if "embedding" in item:
                    key = f"{item['domain']}_{item['geography']}"
                    item["embedding"] = self._get_embedding(key).tolist()
            
            # Save converted data
            self._save_store()
    
    def _fit_vectorizer(self):
        """Fit the vectorizer on all stored texts."""
        texts = []
        for item in self.data["business_analyses"]:
            texts.append(item["text"])
        for item in self.data["risk_profiles"]:
            texts.append(f"{item['domain']}_{item['geography']}")
        
        # If no texts are available, fit with a dummy text to ensure vectorizer is initialized
        if not texts:
            texts = ["dummy text for initialization"]
        
        try:
            self.vectorizer.fit(texts)
        except ValueError as e:
            print(f"Warning: Error fitting vectorizer: {e}")
            # Fallback to a simpler configuration if needed
            self.vectorizer = TfidfVectorizer(
                max_features=1000,
                stop_words='english',
                ngram_range=(1, 1),  # Simplified to unigrams only
                min_df=1,
                max_df=1.0
            )
            self.vectorizer.fit(texts)
    
    def _get_embedding(self, text: str) -> np.ndarray:
        """Get TF-IDF embedding for text."""
        # Ensure vectorizer is fitted
        if not hasattr(self.vectorizer, 'vocabulary_'):
            self._fit_vectorizer()
        return self.vectorizer.transform([text]).toarray()[0]
    
    def _calculate_similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors."""
        # Ensure vectors have the same dimension
        if vec1.shape != vec2.shape:
            # Pad the shorter vector with zeros
            max_dim = max(vec1.shape[0], vec2.shape[0])
            vec1_padded = np.zeros(max_dim)
            vec2_padded = np.zeros(max_dim)
            vec1_padded[:vec1.shape[0]] = vec1
            vec2_padded[:vec2.shape[0]] = vec2
            return cosine_similarity([vec1_padded], [vec2_padded])[0][0]
        return cosine_similarity([vec1], [vec2])[0][0]
    
    def _tokenize_text(self, text: str) -> List[str]:
        # Simple tokenization using regex
        words = re.findall(r'\b\w+\b', text.lower())
        return words
    
    def similarity_search_with_score(self, query: str, k: int = 3) -> List[Tuple[Document, float]]:
        """Search for similar documents and return them with their similarity scores."""
        query_embedding = self._get_embedding(query)
        results = []
        
        # Search in business analyses
        for item in self.data["business_analyses"]:
            if "embedding" not in item:
                continue
            stored_embedding = np.array(item["embedding"])
            similarity = self._calculate_similarity(query_embedding, stored_embedding)
            doc = Document(
                page_content=item["text"],
                metadata={"type": "business_analysis", "analysis": item["analysis"]}
            )
            results.append((doc, similarity))
        
        # Search in risk profiles
        for item in self.data["risk_profiles"]:
            if "embedding" not in item:
                continue
            key = f"{item['domain']}_{item['geography']}"
            stored_embedding = np.array(item["embedding"])
            similarity = self._calculate_similarity(query_embedding, stored_embedding)
            doc = Document(
                page_content=key,
                metadata={"type": "risk_profile", "profile": item["profile"]}
            )
            results.append((doc, similarity))
        
        # Sort by similarity score and return top k
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:k]
    
    def add_business_analysis(self, business_desc: str, analysis: Dict[str, Any]):
        """Add a business analysis to the store."""
        embedding = self._get_embedding(business_desc)
        self.data["business_analyses"].append({
            "embedding": embedding.tolist(),
            "text": business_desc,
            "analysis": analysis
        })
        self._save_store()
        self._fit_vectorizer()  # Refit vectorizer with new data
    
    def add_risk_profile(self, domain: str, geography: str, profile: Dict[str, Any]):
        """Add a risk profile to the store."""
        key = f"{domain}_{geography}"
        embedding = self._get_embedding(key)
        self.data["risk_profiles"].append({
            "embedding": embedding.tolist(),
            "domain": domain,
            "geography": geography,
            "profile": profile
        })
        self._save_store()
        self._fit_vectorizer()  # Refit vectorizer with new data
    
    def find_similar_business(self, business_desc: str, threshold: float = 0.8) -> Optional[Dict[str, Any]]:
        query_embedding = self._get_embedding(business_desc)
        
        for item in self.data["business_analyses"]:
            stored_embedding = np.array(item["embedding"])
            similarity = self._calculate_similarity(query_embedding, stored_embedding)
            
            if similarity >= threshold:
                return item["analysis"]
        return None
    
    def find_similar_risk_profile(self, domain: str, geography: str, threshold: float = 0.8) -> Optional[Dict[str, Any]]:
        key = f"{domain}_{geography}"
        query_embedding = self._get_embedding(key)
        
        for item in self.data["risk_profiles"]:
            stored_embedding = np.array(item["embedding"])
            similarity = self._calculate_similarity(query_embedding, stored_embedding)
            
            if similarity >= threshold:
                return item["profile"]
        return None

def extract_text_from_document(file_content: bytes, file_type: str) -> str:
    """Extract text from uploaded document."""
    if file_type == "text/plain":
        return file_content.decode('utf-8')
    elif file_type == "application/pdf":
        import PyPDF2
        pdf_file = PyPDF2.PdfReader(file_content)
        text = ""
        for page in pdf_file.pages:
            text += page.extract_text()
        return text
    elif file_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        import docx
        doc = docx.Document(file_content)
        return "\n".join([paragraph.text for paragraph in doc.paragraphs])
    else:
        raise ValueError(f"Unsupported file type: {file_type}")

def initialize_vector_store():
    """Initialize the vector store."""
    store = VectorStore()
    return store

def add_to_vector_store(vector_store, text, metadata):
    """
    Add a new document to the vector store with associated metadata.
    
    Args:
        vector_store: VectorStore instance
        text (str): The text to be embedded
        metadata (dict): Associated metadata for the text
    """
    vector_store.add_texts([text], [metadata])

def search_vector_store(vector_store: VectorStore, query: str, k: int = 3) -> List[Tuple[Document, float]]:
    """Search the vector store for similar documents."""
    return vector_store.similarity_search_with_score(query, k=k) 