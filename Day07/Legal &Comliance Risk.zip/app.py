import streamlit as st
import os
from dotenv import load_dotenv
from agents import BusinessModelAnalyzer, RiskDetectionAgent
from utils import initialize_vector_store, extract_text_from_document

# Load environment variables
load_dotenv()

# Initialize Streamlit page
st.set_page_config(
    page_title="Legal & Compliance Risk Identifier",
    page_icon="⚖️",
    layout="wide"
)

# Initialize vector store
vector_store = initialize_vector_store()

# Initialize agents
business_analyzer = BusinessModelAnalyzer(vector_store)
risk_detector = RiskDetectionAgent(vector_store)

# Set up the Streamlit interface
st.title("Legal & Compliance Risk Identifier")
st.write("Analyze your business model and identify potential legal and compliance risks.")

# File upload
uploaded_file = st.file_uploader("Upload a document (PDF, DOCX, or TXT)", 
                                type=["pdf", "docx", "txt"])

# Text input
business_description = st.text_area("Or enter your business description here:")

if uploaded_file is not None:
    # Extract text from uploaded file
    file_content = uploaded_file.read()
    file_type = uploaded_file.type
    business_description = extract_text_from_document(file_content, file_type)
    st.text_area("Extracted text:", business_description, height=200)

if business_description:
    # Analyze business model
    with st.spinner("Analyzing business model..."):
        business_analysis = business_analyzer.analyze(business_description)
        
        st.subheader("Business Analysis")
        st.write(f"**Domain:** {business_analysis['domain']}")
        st.write(f"**Geography:** {business_analysis['geography']}")
        
        # Display similar business analyses
        if business_analysis.get('similar_businesses'):
            st.write("**Similar Business Analyses:**")
            for similar in business_analysis['similar_businesses']:
                with st.expander(f"Similar Business: {similar['domain']} - {similar['geography']}"):
                    st.write(similar['analysis'])
    
    # Analyze legal risks
    with st.spinner("Analyzing legal and compliance risks..."):
        risk_profile = risk_detector.analyze_risks(
            business_analysis['domain'],
            business_analysis['geography']
        )
        
        st.subheader("Legal & Compliance Risks")
        for risk in risk_profile['risks']:
            with st.expander(f"{risk.get('type', 'Risk')} - {risk.get('law', 'Regulation')}"):
                st.write(risk.get('description', 'No description available'))
        
        # Display similar risk profiles
        if risk_profile.get('similar_profiles'):
            st.write("**Similar Risk Profiles:**")
            for similar in risk_profile['similar_profiles']:
                with st.expander(f"Similar Profile: {similar['domain']} - {similar['geography']}"):
                    for risk in similar['profile']['risks']:
                        st.write(f"**{risk.get('type', 'Risk')} - {risk.get('law', 'Regulation')}**")
                        st.write(risk.get('description', 'No description available'))

# Footer
st.markdown("---")
st.markdown("Built with Streamlit and LangChain") 