import os
from typing import Dict, Any, List
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langchain.output_parsers import PydanticOutputParser
from langchain.chains import LLMChain
from langchain.tools import Tool
from langchain.agents import initialize_agent, AgentType
from pydantic import BaseModel, Field
from utils import search_vector_store, VectorStore

class Risk(BaseModel):
    type: str = Field(description="Type of legal or compliance risk")
    law: str = Field(description="Relevant law or regulation")
    description: str = Field(description="Detailed description of the risk and its implications")
    severity: str = Field(description="Risk severity level (High/Medium/Low)")
    mitigation: str = Field(description="Suggested mitigation strategies")

class RiskProfile(BaseModel):
    domain: str = Field(description="Business domain")
    geography: str = Field(description="Geographic region")
    risks: List[Risk] = Field(description="List of identified risks")
    source: str = Field(description="Source of the risk analysis")
    justification: str = Field(description="Justification for the identified risks")

class BusinessModelAnalyzer:
    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=os.getenv("GOOGLE_API_KEY"),
            temperature=0.7,
            convert_system_message_to_human=True
        )
        
        # Define business domain classification tool
        self.domain_classifier = Tool(
            name="BusinessDomainClassifier",
            func=self._classify_business_domain,
            description="Classifies a business description into its primary domain"
        )
        
        # Define geography identifier tool
        self.geography_identifier = Tool(
            name="GeographyIdentifier",
            func=self._identify_geography,
            description="Identifies the geographic region from a business description"
        )
        
        # Initialize the agent with tools
        self.agent = initialize_agent(
            [self.domain_classifier, self.geography_identifier],
            self.llm,
            agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True
        )
    
    def _classify_business_domain(self, business_description: str) -> str:
        """Classify the business domain using LangChain tools."""
        domain_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a business domain classifier. Your task is to identify the primary business domain from a description.
            Common domains include:
            - Healthcare
            - Fintech
            - E-commerce
            - Education
            - Technology
            - Manufacturing
            - Retail
            - Services
            - Real Estate
            - Transportation
            
            Return only the domain name, nothing else."""),
            ("human", "{business_description}")
        ])
        
        chain = LLMChain(llm=self.llm, prompt=domain_prompt)
        domain = chain.run(business_description=business_description)
        return domain.strip()
    
    def _identify_geography(self, business_description: str) -> str:
        """Identify the geographic region using LangChain tools."""
        geography_prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a geography identifier. Your task is to identify the primary geographic region from a business description.
            Consider:
            - Countries
            - Regions
            - Global presence
            - Target markets
            
            Return only the geographic region, nothing else."""),
            ("human", "{business_description}")
        ])
        
        chain = LLMChain(llm=self.llm, prompt=geography_prompt)
        geography = chain.run(business_description=business_description)
        return geography.strip()
    
    def analyze(self, business_description: str) -> Dict[str, Any]:
        # First check vector store for similar businesses
        similar_docs = search_vector_store(self.vector_store, business_description)
        similar_businesses = []
        
        for doc, score in similar_docs:
            if doc.metadata["type"] == "business_analysis" and score > 0.7:
                similar_businesses.append({
                    "domain": doc.metadata["analysis"]["domain"],
                    "geography": doc.metadata["analysis"]["geography"],
                    "analysis": doc.metadata["analysis"]
                })
        
        # If no similar businesses found, use LangChain tools
        if not similar_businesses:
            # Get domain and geography directly
            domain = self._classify_business_domain(business_description)
            geography = self._identify_geography(business_description)
            
            analysis = {
                "domain": domain,
                "geography": geography,
                "source": "LangChain Analysis",
                "justification": f"Domain classified as {domain} based on business description. Geography identified as {geography} based on target markets and operations."
            }
            
            # Store the new analysis
            self.vector_store.add_business_analysis(
                business_description,
                analysis
            )
            
            return {
                "domain": analysis["domain"],
                "geography": analysis["geography"],
                "source": analysis["source"],
                "justification": analysis["justification"],
                "similar_businesses": []
            }
        
        # Return the most similar business analysis
        return {
            "domain": similar_businesses[0]["domain"],
            "geography": similar_businesses[0]["geography"],
            "source": "Vector Store",
            "justification": "Based on similar business analysis",
            "similar_businesses": similar_businesses
        }

class RiskDetectionAgent:
    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=os.getenv("GOOGLE_API_KEY"),
            temperature=0.7,
            convert_system_message_to_human=True
        )
        self.parser = PydanticOutputParser(pydantic_object=RiskProfile)
        
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a comprehensive legal and compliance risk analyzer. Your task is to analyze the business domain and geography to identify potential legal and compliance risks. You MUST check for the following key areas:

1. Data Privacy & Protection:
   - GDPR compliance (if operating in EU)
   - HIPAA compliance (if handling healthcare data)
   - CCPA/CPRA (if operating in California)
   - Other relevant data protection laws

2. Intellectual Property:
   - Patent risks
   - Trademark considerations
   - Copyright issues
   - Trade secret protection

3. Tax Compliance:
   - Corporate tax obligations
   - Sales tax/VAT requirements
   - International tax implications
   - Transfer pricing considerations

4. Industry-Specific Regulations:
   - Sector-specific compliance requirements
   - Licensing requirements
   - Industry standards

For each identified risk, provide:
- Type of risk
- Relevant law or regulation
- Detailed description of the risk
- Severity level (High/Medium/Low)
- Suggested mitigation strategies

{format_instructions}

Be thorough and specific in your analysis, considering both current operations and potential future implications."""),
            ("human", """Business Domain: {domain}
Geography: {geography}

Please analyze the legal and compliance risks for this business, focusing on data privacy, IP protection, tax obligations, and industry-specific regulations.""")
        ])
    
    def analyze_risks(self, domain: str, geography: str) -> Dict[str, Any]:
        # First check vector store for similar risk profiles
        query = f"{domain} {geography}"
        similar_docs = search_vector_store(self.vector_store, query)
        similar_profiles = []
        
        for doc, score in similar_docs:
            if doc.metadata["type"] == "risk_profile" and score > 0.7:
                similar_profiles.append({
                    "domain": doc.metadata["profile"]["domain"],
                    "geography": doc.metadata["profile"]["geography"],
                    "profile": doc.metadata["profile"]
                })
        
        # If no similar profiles found, use LLM
        if not similar_profiles:
            chain = self.prompt | self.llm | self.parser
            result = chain.invoke({
                "domain": domain,
                "geography": geography,
                "format_instructions": self.parser.get_format_instructions()
            })
            
            # Store the new risk profile
            self.vector_store.add_risk_profile(
                domain,
                geography,
                result.dict()
            )
            
            return {
                "domain": result.domain,
                "geography": result.geography,
                "risks": [risk.dict() for risk in result.risks],
                "source": result.source,
                "justification": result.justification,
                "similar_profiles": []
            }
        
        # Return the most similar risk profile
        return {
            "domain": similar_profiles[0]["domain"],
            "geography": similar_profiles[0]["geography"],
            "risks": similar_profiles[0]["profile"]["risks"],
            "source": "Vector Store",
            "justification": "Based on similar risk profile",
            "similar_profiles": similar_profiles
        } 