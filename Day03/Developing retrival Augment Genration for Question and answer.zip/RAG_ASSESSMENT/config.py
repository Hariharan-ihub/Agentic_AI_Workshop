import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# API Keys
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Document Processing
CHUNK_SIZE = 1000  # Number of characters per chunk
CHUNK_OVERLAP = 200  # Number of characters to overlap between chunks

# Embedding Model
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
EMBEDDING_DIMENSION = 384

# Vector Database
VECTOR_DB_TYPE = "chroma"  # Options: "chroma" or "faiss"
COLLECTION_NAME = "research_papers"

# Retrieval
TOP_K_RESULTS = 3  # Number of chunks to retrieve for each query

# Answer Generation
MODEL_NAME = "gpt-4"
TEMPERATURE = 0.7
MAX_TOKENS = 500

# File Paths
DATA_DIR = "data"
PROCESSED_DIR = "data/processed"
VECTOR_DB_DIR = "data/vector_db"

# Create necessary directories if they don't exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(VECTOR_DB_DIR, exist_ok=True)

# Test Questions
TEST_QUESTIONS = [
    "What are the main components of a RAG model, and how do they interact?",
    "What are the two sub-layers in each encoder layer of the Transformer model?",
    "Explain positional encoding in Transformers and why it's necessary.",
    "What is multi-head attention in Transformers and why is it useful?",
    "What is few-shot learning and how does GPT-3 apply it during inference?"
] 