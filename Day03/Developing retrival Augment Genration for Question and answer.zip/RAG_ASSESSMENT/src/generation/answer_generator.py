from typing import List, Dict, Any
import openai
from ..config import MODEL_NAME, TEMPERATURE, MAX_TOKENS, OPENAI_API_KEY

class AnswerGenerator:
    """Generates answers using GPT-4 based on retrieved context."""
    
    def __init__(
        self,
        model_name: str = MODEL_NAME,
        temperature: float = TEMPERATURE,
        max_tokens: int = MAX_TOKENS
    ):
        """
        Initialize the answer generator.
        
        Args:
            model_name (str): Name of the GPT model to use
            temperature (float): Temperature for generation
            max_tokens (int): Maximum tokens in generated response
        """
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        # Set OpenAI API key
        openai.api_key = OPENAI_API_KEY
    
    def _create_prompt(self, query: str, context: List[Dict[str, Any]]) -> str:
        """
        Create a prompt for the language model.
        
        Args:
            query (str): User query
            context (List[Dict[str, Any]]): Retrieved context
            
        Returns:
            str: Formatted prompt
        """
        # Format context
        context_text = []
        for i, doc in enumerate(context, 1):
            source = doc["metadata"]["source"]
            page = doc["metadata"]["page"]
            text = doc["text"]
            
            context_text.append(
                f"[{i}] Source: {source}, Page: {page}\n"
                f"Text: {text}\n"
            )
        
        # Create prompt
        prompt = (
            "Given the following context from research papers, answer the user's query. "
            "Cite the relevant sources using the format [source, page]. "
            "If the answer cannot be found in the context, say so.\n\n"
            "Context:\n"
            f"{''.join(context_text)}\n"
            f"Query: {query}\n"
            "Answer:"
        )
        
        return prompt
    
    def generate_answer(self, query: str, context: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate an answer using the language model.
        
        Args:
            query (str): User query
            context (List[Dict[str, Any]]): Retrieved context
            
        Returns:
            Dict[str, Any]: Generated answer with metadata
        """
        prompt = self._create_prompt(query, context)
        
        try:
            response = openai.ChatCompletion.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": "You are a helpful AI assistant that answers questions about research papers."},
                    {"role": "user", "content": prompt}
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens
            )
            
            answer = response.choices[0].message.content
            
            return {
                "answer": answer,
                "sources": [
                    {
                        "source": doc["metadata"]["source"],
                        "page": doc["metadata"]["page"]
                    }
                    for doc in context
                ]
            }
            
        except Exception as e:
            return {
                "answer": f"Error generating answer: {str(e)}",
                "sources": []
            }
    
    def format_answer(self, result: Dict[str, Any]) -> str:
        """
        Format the generated answer for display.
        
        Args:
            result (Dict[str, Any]): Generated answer with metadata
            
        Returns:
            str: Formatted answer
        """
        answer = result["answer"]
        sources = result["sources"]
        
        # Format sources
        sources_text = "\nSources:\n"
        for source in sources:
            sources_text += f"- {source['source']}, Page {source['page']}\n"
        
        return f"{answer}\n{sources_text}" 