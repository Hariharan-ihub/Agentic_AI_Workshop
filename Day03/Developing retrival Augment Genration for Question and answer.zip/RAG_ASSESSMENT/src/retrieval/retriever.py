from typing import List, Dict, Any
import numpy as np

from ..preprocessing.embedding_generator import EmbeddingGenerator
from ..preprocessing.vector_db_manager import VectorDBManager
from ..config import TOP_K_RESULTS

class Retriever:
    """Handles semantic search and document retrieval."""
    
    def __init__(
        self,
        embedding_generator: EmbeddingGenerator,
        vector_db: VectorDBManager,
        top_k: int = TOP_K_RESULTS
    ):
        """
        Initialize the retriever.
        
        Args:
            embedding_generator (EmbeddingGenerator): Generator for embeddings
            vector_db (VectorDBManager): Vector database manager
            top_k (int): Number of results to return
        """
        self.embedding_generator = embedding_generator
        self.vector_db = vector_db
        self.top_k = top_k
    
    def retrieve(self, query: str) -> List[Dict[str, Any]]:
        """
        Retrieve relevant documents for a query.
        
        Args:
            query (str): User query
            
        Returns:
            List[Dict[str, Any]]: List of relevant documents with metadata
        """
        # Generate query embedding
        query_embedding = self.embedding_generator.generate_embedding(query)
        
        # Search vector database
        results = self.vector_db.search(query_embedding, k=self.top_k)
        
        return results
    
    def format_results(self, results: List[Dict[str, Any]]) -> str:
        """
        Format retrieval results for display.
        
        Args:
            results (List[Dict[str, Any]]): List of retrieved documents
            
        Returns:
            str: Formatted string of results
        """
        formatted_results = []
        
        for i, result in enumerate(results, 1):
            source = result["metadata"]["source"]
            page = result["metadata"]["page"]
            text = result["text"]
            
            formatted_result = (
                f"Result {i}:\n"
                f"Source: {source}\n"
                f"Page: {page}\n"
                f"Text: {text}\n"
                f"Relevance Score: {1 - result['distance']:.4f}\n"
            )
            formatted_results.append(formatted_result)
        
        return "\n".join(formatted_results) 