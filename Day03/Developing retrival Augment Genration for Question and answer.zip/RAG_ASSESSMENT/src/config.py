"""
Configuration settings for the RAG system.
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Document processing settings
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200

# Embedding model settings
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# Vector database settings
VECTOR_DB_TYPE = "chroma"
COLLECTION_NAME = "research_papers"

# Directory settings
DATA_DIR = os.path.join("data", "documents")
VECTOR_DB_DIR = os.path.join("data", "vector_db")

# LLM settings
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-3.5-turbo")
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.7"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "500"))
TOP_K_RESULTS = 3

# OpenAI API Key
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Test questions for evaluation
TEST_QUESTIONS = [
    {
        "question": "What are the main challenges in implementing RAG systems?",
        "expected_keywords": ["retrieval", "generation", "accuracy", "latency"]
    },
    {
        "question": "How does vector similarity search work in RAG?",
        "expected_keywords": ["embeddings", "cosine similarity", "vector space"]
    },
    {
        "question": "What are the best practices for chunking documents in RAG?",
        "expected_keywords": ["overlap", "context", "semantic", "chunk size"]
    }
] 