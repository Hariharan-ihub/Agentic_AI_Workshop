import fitz  # PyMuPDF
import os
from typing import List, Dict, Any
from dataclasses import dataclass
from tqdm import tqdm

@dataclass
class DocumentChunk:
    """Represents a chunk of text from a document with metadata."""
    text: str
    metadata: Dict[str, Any]
    chunk_id: str

class PDFProcessor:
    """Handles loading and processing of PDF documents."""
    
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        """
        Initialize the PDF processor.
        
        Args:
            chunk_size (int): Size of each text chunk in characters
            chunk_overlap (int): Number of characters to overlap between chunks
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
    
    def load_pdf(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Load a PDF file and extract its text and metadata.
        
        Args:
            file_path (str): Path to the PDF file
            
        Returns:
            List[Dict[str, Any]]: List of dictionaries containing text and metadata
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PDF file not found: {file_path}")
        
        doc = fitz.open(file_path)
        pages = []
        
        for page_num in range(len(doc)):
            page = doc[page_num]
            text = page.get_text()
            
            # Extract metadata
            metadata = {
                "source": os.path.basename(file_path),
                "page": page_num + 1,
                "total_pages": len(doc)
            }
            
            pages.append({
                "text": text,
                "metadata": metadata
            })
        
        doc.close()
        return pages
    
    def chunk_text(self, pages: List[Dict[str, Any]]) -> List[DocumentChunk]:
        """
        Split text into overlapping chunks.
        
        Args:
            pages (List[Dict[str, Any]]): List of pages with text and metadata
            
        Returns:
            List[DocumentChunk]: List of document chunks
        """
        chunks = []
        chunk_id = 0
        
        for page in pages:
            text = page["text"]
            metadata = page["metadata"]
            
            # Split text into chunks
            start = 0
            while start < len(text):
                end = start + self.chunk_size
                chunk_text = text[start:end]
                
                # Create chunk with metadata
                chunk = DocumentChunk(
                    text=chunk_text,
                    metadata=metadata.copy(),
                    chunk_id=f"{metadata['source']}_{chunk_id}"
                )
                chunks.append(chunk)
                
                # Move start position, accounting for overlap
                start = end - self.chunk_overlap
                chunk_id += 1
        
        return chunks
    
    def process_directory(self, directory_path: str) -> List[DocumentChunk]:
        """
        Process all PDF files in a directory.
        
        Args:
            directory_path (str): Path to directory containing PDF files
            
        Returns:
            List[DocumentChunk]: List of all document chunks from all PDFs
        """
        all_chunks = []
        
        # Get all PDF files in directory
        pdf_files = [f for f in os.listdir(directory_path) if f.endswith('.pdf')]
        
        for pdf_file in tqdm(pdf_files, desc="Processing PDFs"):
            file_path = os.path.join(directory_path, pdf_file)
            pages = self.load_pdf(file_path)
            chunks = self.chunk_text(pages)
            all_chunks.extend(chunks)
        
        return all_chunks 