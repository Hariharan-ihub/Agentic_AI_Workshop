import os
from typing import List
import argparse
from tqdm import tqdm

from .pdf_processor import PDFProcessor, DocumentChunk
from .embedding_generator import EmbeddingGenerator
from .vector_db_manager import VectorDBManager
from ..config import (
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    EMBEDDING_MODEL,
    VECTOR_DB_TYPE,
    COLLECTION_NAME,
    DATA_DIR,
    VECTOR_DB_DIR
)

def process_documents(
    data_dir: str = DATA_DIR,
    chunk_size: int = CHUNK_SIZE,
    chunk_overlap: int = CHUNK_OVERLAP,
    embedding_model: str = EMBEDDING_MODEL,
    vector_db_type: str = VECTOR_DB_TYPE,
    collection_name: str = COLLECTION_NAME
) -> None:
    """
    Process documents and create vector embeddings.
    
    Args:
        data_dir (str): Directory containing PDF documents
        chunk_size (int): Size of text chunks
        chunk_overlap (int): Overlap between chunks
        embedding_model (str): Name of the embedding model
        vector_db_type (str): Type of vector database to use
        collection_name (str): Name of the collection
    """
    print("Initializing components...")
    pdf_processor = PDFProcessor(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    embedding_generator = EmbeddingGenerator(model_name=embedding_model)
    vector_db = VectorDBManager(db_type=vector_db_type, collection_name=collection_name)
    
    print("Processing PDF documents...")
    chunks = pdf_processor.process_directory(data_dir)
    
    if not chunks:
        print("No documents found to process!")
        return
    
    print(f"Generated {len(chunks)} chunks from documents")
    
    print("Generating embeddings...")
    embedding_data = embedding_generator.generate_embeddings(chunks)
    
    print("Storing in vector database...")
    vector_db.add_documents(chunks, embedding_data["embeddings"])
    
    # Save vector database
    vector_db.save(VECTOR_DB_DIR)
    
    print("Processing complete!")

def main():
    parser = argparse.ArgumentParser(description="Process PDF documents for RAG system")
    parser.add_argument("--data-dir", default=DATA_DIR, help="Directory containing PDF documents")
    parser.add_argument("--chunk-size", type=int, default=CHUNK_SIZE, help="Size of text chunks")
    parser.add_argument("--chunk-overlap", type=int, default=CHUNK_OVERLAP, help="Overlap between chunks")
    parser.add_argument("--embedding-model", default=EMBEDDING_MODEL, help="Name of the embedding model")
    parser.add_argument("--vector-db-type", default=VECTOR_DB_TYPE, help="Type of vector database to use")
    parser.add_argument("--collection-name", default=COLLECTION_NAME, help="Name of the collection")
    
    args = parser.parse_args()
    
    process_documents(
        data_dir=args.data_dir,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
        embedding_model=args.embedding_model,
        vector_db_type=args.vector_db_type,
        collection_name=args.collection_name
    )

if __name__ == "__main__":
    main() 