import os
from typing import List, Dict, Any, Optional, Union
import numpy as np
import chromadb
from chromadb.config import Settings
from ..preprocessing.pdf_processor import DocumentChunk

class VectorDBManager:
    """Manages vector storage and retrieval using ChromaDB."""
    
    def __init__(self, db_type: str = "chroma", collection_name: str = "research_papers"):
        """
        Initialize the vector database manager.
        
        Args:
            db_type (str): Type of vector database to use (only "chroma" is supported)
            collection_name (str): Name of the collection
        """
        if db_type.lower() != "chroma":
            raise ValueError("Only 'chroma' db_type is supported")
            
        self.collection_name = collection_name
        self._init_chroma()
    
    def _init_chroma(self):
        """Initialize ChromaDB client and collection."""
        self.client = chromadb.Client(Settings(
            persist_directory="data/vector_db/chroma",
            anonymized_telemetry=False
        ))
        
        # Create or get collection
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"}
        )
    
    def add_documents(self, chunks: List[DocumentChunk], embeddings: np.ndarray):
        """
        Add document chunks and their embeddings to the vector database.
        
        Args:
            chunks (List[DocumentChunk]): List of document chunks
            embeddings (np.ndarray): Array of embeddings for the chunks
        """
        ids = [chunk.chunk_id for chunk in chunks]
        texts = [chunk.text for chunk in chunks]
        metadatas = [chunk.metadata for chunk in chunks]
        
        self.collection.add(
            embeddings=embeddings,
            documents=texts,
            metadatas=metadatas,
            ids=ids
        )
    
    def search(self, query_embedding: List[float], k: int = 3) -> List[Dict[str, Any]]:
        """
        Search for similar documents using a query embedding.
        
        Args:
            query_embedding (List[float]): Query embedding vector
            k (int): Number of results to return
            
        Returns:
            List[Dict[str, Any]]: List of similar documents with metadata
        """
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=k
        )
        
        return [
            {
                "text": doc,
                "metadata": meta,
                "distance": dist
            }
            for doc, meta, dist in zip(
                results["documents"][0],
                results["metadatas"][0],
                results["distances"][0]
            )
        ]
    
    def save(self, path: str):
        """
        Save the vector database to disk.
        ChromaDB automatically persists to disk.
        
        Args:
            path (str): Path to save the database (not used, kept for compatibility)
        """
        pass
    
    def load(self, path: str):
        """
        Load the vector database from disk.
        ChromaDB automatically loads from disk.
        
        Args:
            path (str): Path to load the database from (not used, kept for compatibility)
        """
        pass 