import os
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any
import numpy as np
from tqdm import tqdm
from src.preprocessing.pdf_processor import DocumentChunk
import google.generativeai as genai

class EmbeddingGenerator:
    """Generates vector embeddings for document chunks using sentence transformers."""
    
    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """
        Initialize the embedding generator.
        
        Args:
            model_name (str): Name of the sentence transformer model to use
        """
        self.model = SentenceTransformer(model_name)
        genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
        self.gemini_model = genai.GenerativeModel(os.getenv("MODEL_NAME", "gemini-pro"))
    
    def generate_embeddings(self, chunks: List[DocumentChunk]) -> Dict[str, Any]:
        """
        Generate embeddings for a list of document chunks.
        
        Args:
            chunks (List[DocumentChunk]): List of document chunks to embed
            
        Returns:
            Dict[str, Any]: Dictionary containing embeddings and metadata
        """
        texts = [chunk.text for chunk in chunks]
        metadata = [chunk.metadata for chunk in chunks]
        chunk_ids = [chunk.chunk_id for chunk in chunks]
        
        # Generate embeddings
        embeddings = self.model.encode(
            texts,
            show_progress_bar=True,
            convert_to_numpy=True
        )
        
        return {
            "embeddings": embeddings.tolist(),
            "metadata": metadata,
            "chunk_ids": chunk_ids,
            "texts": texts
        }
    
    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text.
        
        Args:
            text (str): Text to generate embedding for
            
        Returns:
            List[float]: Vector embedding as a list of floats
        """
        return self.model.encode(text, convert_to_numpy=True).tolist()
    
    def batch_generate_embeddings(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """
        Generate embeddings for a list of texts in batches.
        
        Args:
            texts (List[str]): List of texts to generate embeddings for
            batch_size (int): Size of batches for processing
            
        Returns:
            np.ndarray: Array of embeddings
        """
        all_embeddings = []
        
        for i in tqdm(range(0, len(texts), batch_size), desc="Generating embeddings"):
            batch_texts = texts[i:i + batch_size]
            batch_embeddings = self.model.encode(
                batch_texts,
                show_progress_bar=False,
                convert_to_numpy=True
            )
            all_embeddings.append(batch_embeddings)
        
        return np.vstack(all_embeddings)
    
    def generate_answer(self, question: str, context: str) -> str:
        """
        Generate answer using Gemini.
        """
        prompt = f"""Based on the following context, answer the question. If the answer cannot be found in the context, say so.

Context:
{context}

Question: {question}

Answer:"""
        
        response = self.gemini_model.generate_content(prompt)
        return response.text 