import os
from typing import List, Dict
import pdfplumber
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from langchain.schema import Document

class DocumentProcessor:
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
        )

    def process_pdf(self, file_path: str) -> List[Document]:
        """Process a PDF file and return chunks of text."""
        try:
            with pdfplumber.open(file_path) as pdf:
                text = ""
                for page in pdf.pages:
                    text += page.extract_text() + "\n"
                
                # Create a Document object with metadata
                doc = Document(
                    page_content=text,
                    metadata={
                        "source": file_path,
                        "file_type": "pdf",
                        "total_pages": len(pdf.pages)
                    }
                )
                
                # Split the document into chunks
                chunks = self.text_splitter.split_documents([doc])
                return chunks
        except Exception as e:
            print(f"Error processing PDF {file_path}: {str(e)}")
            return []

    def process_text(self, file_path: str) -> List[Document]:
        """Process a text file and return chunks of text."""
        try:
            loader = TextLoader(file_path)
            documents = loader.load()
            chunks = self.text_splitter.split_documents(documents)
            return chunks
        except Exception as e:
            print(f"Error processing text file {file_path}: {str(e)}")
            return []

    def process_file(self, file_path: str) -> List[Document]:
        """Process a file based on its extension."""
        file_ext = os.path.splitext(file_path)[1].lower()
        
        if file_ext == '.pdf':
            return self.process_pdf(file_path)
        elif file_ext in ['.txt', '.md']:
            return self.process_text(file_path)
        else:
            print(f"Unsupported file type: {file_ext}")
            return [] 