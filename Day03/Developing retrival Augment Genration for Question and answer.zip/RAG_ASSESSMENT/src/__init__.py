"""
RAG-based Question Answering System
""" 