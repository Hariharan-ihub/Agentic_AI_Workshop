from typing import List, Dict, Any
import json
from datetime import datetime
from ..retrieval.retriever import Retriever
from ..generation.answer_generator import AnswerGenerator
from ..config import TEST_QUESTIONS

class Evaluator:
    """Evaluates the RAG system using test questions."""
    
    def __init__(
        self,
        retriever: Retriever,
        answer_generator: AnswerGenerator,
        test_questions: List[str] = TEST_QUESTIONS
    ):
        """
        Initialize the evaluator.
        
        Args:
            retriever (Retriever): Document retriever
            answer_generator (AnswerGenerator): Answer generator
            test_questions (List[str]): List of test questions
        """
        self.retriever = retriever
        self.answer_generator = answer_generator
        self.test_questions = test_questions
    
    def evaluate(self) -> Dict[str, Any]:
        """
        Run evaluation on test questions.
        
        Returns:
            Dict[str, Any]: Evaluation results
        """
        results = []
        
        for question in self.test_questions:
            # Retrieve relevant documents
            retrieved_docs = self.retriever.retrieve(question)
            
            # Generate answer
            answer_result = self.answer_generator.generate_answer(question, retrieved_docs)
            
            # Store results
            result = {
                "question": question,
                "retrieved_docs": [
                    {
                        "source": doc["metadata"]["source"],
                        "page": doc["metadata"]["page"],
                        "relevance_score": 1 - doc["distance"]
                    }
                    for doc in retrieved_docs
                ],
                "answer": answer_result["answer"],
                "sources": answer_result["sources"]
            }
            
            results.append(result)
        
        return {
            "timestamp": datetime.now().isoformat(),
            "num_questions": len(self.test_questions),
            "results": results
        }
    
    def save_results(self, results: Dict[str, Any], output_file: str):
        """
        Save evaluation results to a file.
        
        Args:
            results (Dict[str, Any]): Evaluation results
            output_file (str): Path to output file
        """
        with open(output_file, "w") as f:
            json.dump(results, f, indent=2)
    
    def print_results(self, results: Dict[str, Any]):
        """
        Print evaluation results.
        
        Args:
            results (Dict[str, Any]): Evaluation results
        """
        print(f"\nEvaluation Results ({results['timestamp']})")
        print(f"Number of questions: {results['num_questions']}\n")
        
        for i, result in enumerate(results["results"], 1):
            print(f"Question {i}: {result['question']}")
            print("\nRetrieved Documents:")
            for doc in result["retrieved_docs"]:
                print(f"- {doc['source']}, Page {doc['page']} (Score: {doc['relevance_score']:.4f})")
            
            print("\nGenerated Answer:")
            print(result["answer"])
            print("\nSources:")
            for source in result["sources"]:
                print(f"- {source['source']}, Page {source['page']}")
            print("\n" + "="*80 + "\n") 