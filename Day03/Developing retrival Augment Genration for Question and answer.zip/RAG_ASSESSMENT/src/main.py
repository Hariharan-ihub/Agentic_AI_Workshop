import os
from typing import List, Optional
from dotenv import load_dotenv
from src.preprocessing.pdf_processor import PDFProcessor
from src.preprocessing.embedding_generator import EmbeddingGenerator
from src.preprocessing.vector_db_manager import VectorDBManager
from src.retrieval.retriever import Retriever
from src.generation.answer_generator import AnswerGenerator
from src.evaluation.evaluator import Evaluator
from src.utils.file_handler import FileHandler
from src.utils.file_uploader import FileUploaderGUI
from src.config import (
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    EMBEDDING_MODEL,
    VECTOR_DB_TYPE,
    COLLECTION_NAME,
    DATA_DIR,
    VECTOR_DB_DIR,
    MODEL_NAME,
    TEMPERATURE,
    MAX_TOKENS,
    TOP_K_RESULTS,
    OPENAI_API_KEY,
    TEST_QUESTIONS
)
from src.utils.rag_gui import RAGGUI

# Load environment variables
load_dotenv()

def initialize_components():
    """Initialize all components of the RAG system."""
    # Initialize preprocessing components
    pdf_processor = PDFProcessor(chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP)
    embedding_generator = EmbeddingGenerator(model_name=EMBEDDING_MODEL)
    vector_db = VectorDBManager(db_type=VECTOR_DB_TYPE, collection_name=COLLECTION_NAME)
    
    # Initialize retrieval and generation components
    retriever = Retriever(embedding_generator, vector_db, top_k=TOP_K_RESULTS)
    answer_generator = AnswerGenerator(
        model_name=MODEL_NAME,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS
    )
    
    # Initialize file handler
    file_handler = FileHandler(data_dir=DATA_DIR)
    
    return {
        "pdf_processor": pdf_processor,
        "embedding_generator": embedding_generator,
        "vector_db": vector_db,
        "retriever": retriever,
        "answer_generator": answer_generator,
        "file_handler": file_handler
    }

def process_documents(components):
    """Process documents and create vector embeddings."""
    print("Processing documents...")
    chunks = components["pdf_processor"].process_directory(DATA_DIR)
    
    if not chunks:
        print("No documents found to process!")
        return False
    
    print(f"Generated {len(chunks)} chunks from documents")
    
    print("Generating embeddings...")
    embedding_data = components["embedding_generator"].generate_embeddings(chunks)
    
    print("Storing in vector database...")
    components["vector_db"].add_documents(chunks, embedding_data["embeddings"])
    
    # Save vector database
    components["vector_db"].save(VECTOR_DB_DIR)
    
    print("Processing complete!")
    return True

def answer_question(components, question: str):
    """Answer a single question using the RAG system."""
    # Retrieve relevant documents
    retrieved_docs = components["retriever"].retrieve(question)
    
    # Generate answer
    answer_result = components["answer_generator"].generate_answer(question, retrieved_docs)
    
    # Format and print results
    print("\nRetrieved Documents:")
    print(components["retriever"].format_results(retrieved_docs))
    
    print("\nGenerated Answer:")
    print(components["answer_generator"].format_answer(answer_result))

def run_evaluation(components):
    """Run evaluation on test questions."""
    evaluator = Evaluator(
        components["retriever"],
        components["answer_generator"]
    )
    
    print("Running evaluation...")
    results = evaluator.evaluate()
    
    # Save results
    output_file = os.path.join("data", "evaluation_results.json")
    evaluator.save_results(results, output_file)
    
    # Print results
    evaluator.print_results(results)

def handle_file_upload(components):
    """Handle file upload process."""
    file_handler = components["file_handler"]
    
    print("\nFile Upload Options:")
    print("1. Upload a single file")
    print("2. Upload multiple files")
    print("3. List uploaded files")
    print("4. Remove a file")
    print("5. Clear all files")
    print("6. Return to main menu")
    
    choice = input("\nEnter your choice (1-6): ").strip()
    
    if choice == "1":
        file_path = input("Enter the path to the PDF file: ").strip()
        try:
            uploaded_path = file_handler.upload_file(file_path)
            print(f"File uploaded successfully: {uploaded_path}")
        except Exception as e:
            print(f"Error uploading file: {str(e)}")
    
    elif choice == "2":
        file_paths = input("Enter the paths to the PDF files (comma-separated): ").strip().split(",")
        file_paths = [path.strip() for path in file_paths]
        uploaded_paths = file_handler.upload_files(file_paths)
        print(f"Uploaded {len(uploaded_paths)} files successfully")
    
    elif choice == "3":
        files = file_handler.list_uploaded_files()
        if files:
            print("\nUploaded files:")
            for file in files:
                print(f"- {file}")
        else:
            print("No files uploaded yet")
    
    elif choice == "4":
        filename = input("Enter the filename to remove: ").strip()
        if file_handler.remove_file(filename):
            print(f"File {filename} removed successfully")
        else:
            print(f"File {filename} not found")
    
    elif choice == "5":
        confirm = input("Are you sure you want to remove all files? (y/n): ").strip().lower()
        if confirm == "y":
            file_handler.clear_data_directory()
            print("All files removed")
    
    elif choice == "6":
        return
    
    else:
        print("Invalid choice")

class RAGSystem:
    def __init__(self):
        """Initialize the RAG system components."""
        self.pdf_processor = PDFProcessor()
        self.embedding_generator = EmbeddingGenerator()
        self.vector_db = VectorDBManager(db_type=VECTOR_DB_TYPE)
        
        # Create necessary directories
        os.makedirs("data/uploads", exist_ok=True)
        os.makedirs("data/processed", exist_ok=True)
        os.makedirs("data/embeddings", exist_ok=True)
    
    def upload_files(self):
        """Upload files using GUI."""
        uploader = FileUploaderGUI("data/uploads")
        uploader.run()
    
    def process_documents(self):
        """Process uploaded documents."""
        upload_dir = "data/uploads"
        processed_dir = "data/processed"
        
        # Get list of PDF files
        pdf_files = [f for f in os.listdir(upload_dir) if f.endswith('.pdf')]
        
        if not pdf_files:
            print("No PDF files found in uploads directory.")
            return
        
        print(f"\nProcessing {len(pdf_files)} documents...")
        
        for pdf_file in pdf_files:
            print(f"\nProcessing {pdf_file}...")
            
            # Process PDF
            pdf_path = os.path.join(upload_dir, pdf_file)
            chunks = self.pdf_processor.process_pdf(pdf_path)
            
            # Generate embeddings
            embeddings = self.embedding_generator.generate_embeddings(chunks)
            
            # Add to vector database
            self.vector_db.add_documents(chunks, embeddings)
            
            print(f"Completed processing {pdf_file}")
        
        print("\nAll documents processed successfully!")
    
    def ask_question(self, question: str) -> str:
        """Ask a question about the processed documents."""
        # Generate embedding for the question
        question_embedding = self.embedding_generator.generate_embedding(question)
        
        # Search for relevant documents
        relevant_docs = self.vector_db.search(question_embedding)
        
        # Generate answer using OpenAI
        prompt = f"""Based on the following context, answer the question. If the answer cannot be found in the context, say so.

Context:
{relevant_docs}

Question: {question}

Answer:"""
        
        response = self.embedding_generator.client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "user", "content": prompt}],
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS
        )
        
        return response.choices[0].message.content
    
    def run_interactive(self):
        """Run the RAG system in interactive mode."""
        while True:
            print("\nRAG System Menu:")
            print("1. Upload/Manage Files")
            print("2. Process Documents")
            print("3. Ask Questions")
            print("4. Run Evaluation")
            print("5. Exit")
            
            choice = input("\nEnter your choice (1-5): ")
            
            if choice == "1":
                self.upload_files()
            
            elif choice == "2":
                self.process_documents()
            
            elif choice == "3":
                question = input("\nEnter your question: ")
                answer = self.ask_question(question)
                print("\nAnswer:", answer)
            
            elif choice == "4":
                print("\nRunning evaluation on test questions...")
                for question in TEST_QUESTIONS:
                    print(f"\nQuestion: {question}")
                    answer = self.ask_question(question)
                    print("Answer:", answer)
            
            elif choice == "5":
                print("\nExiting RAG System. Goodbye!")
                break
            
            else:
                print("\nInvalid choice. Please try again.")

if __name__ == "__main__":
    app = RAGGUI()
    app.run() 