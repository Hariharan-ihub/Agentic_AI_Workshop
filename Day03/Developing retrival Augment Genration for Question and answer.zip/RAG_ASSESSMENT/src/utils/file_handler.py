import os
import shutil
from typing import List
from pathlib import Path

class FileHandler:
    """Handles file operations for the RAG system."""
    
    def __init__(self, data_dir: str = "data"):
        """
        Initialize the file handler.
        
        Args:
            data_dir (str): Directory to store uploaded files
        """
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
    
    def upload_file(self, file_path: str) -> str:
        """
        Upload a file to the data directory.
        
        Args:
            file_path (str): Path to the file to upload
            
        Returns:
            str: Path to the uploaded file
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Get filename and create destination path
        filename = os.path.basename(file_path)
        dest_path = os.path.join(self.data_dir, filename)
        
        # Copy file to data directory
        shutil.copy2(file_path, dest_path)
        
        return dest_path
    
    def upload_files(self, file_paths: List[str]) -> List[str]:
        """
        Upload multiple files to the data directory.
        
        Args:
            file_paths (List[str]): List of paths to files to upload
            
        Returns:
            List[str]: List of paths to uploaded files
        """
        uploaded_paths = []
        for file_path in file_paths:
            try:
                uploaded_path = self.upload_file(file_path)
                uploaded_paths.append(uploaded_path)
            except Exception as e:
                print(f"Error uploading {file_path}: {str(e)}")
        
        return uploaded_paths
    
    def list_uploaded_files(self) -> List[str]:
        """
        List all uploaded files in the data directory.
        
        Returns:
            List[str]: List of filenames
        """
        return [f for f in os.listdir(self.data_dir) if f.endswith('.pdf')]
    
    def remove_file(self, filename: str) -> bool:
        """
        Remove a file from the data directory.
        
        Args:
            filename (str): Name of the file to remove
            
        Returns:
            bool: True if file was removed, False otherwise
        """
        file_path = os.path.join(self.data_dir, filename)
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        return False
    
    def clear_data_directory(self) -> None:
        """Remove all files from the data directory."""
        for filename in self.list_uploaded_files():
            self.remove_file(filename) 