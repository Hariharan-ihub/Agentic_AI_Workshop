import tkinter as tk
from tkinter import filedialog, messagebox
import os
import shutil
from typing import List, Optional

class FileUploaderGUI:
    def __init__(self, upload_dir: str):
        """
        Initialize the file uploader GUI.
        
        Args:
            upload_dir (str): Directory to upload files to
        """
        self.upload_dir = upload_dir
        self.window = tk.Tk()
        self.window.title("RAG System - File Uploader")
        self.window.geometry("600x400")
        
        # Create upload directory if it doesn't exist
        os.makedirs(upload_dir, exist_ok=True)
        
        self._create_widgets()
    
    def _create_widgets(self):
        """Create GUI widgets."""
        # Title
        title_label = tk.Label(
            self.window,
            text="Upload Research Papers",
            font=("Arial", 16, "bold")
        )
        title_label.pack(pady=20)
        
        # Upload button
        upload_btn = tk.Button(
            self.window,
            text="Select PDF Files",
            command=self._upload_files,
            width=20,
            height=2
        )
        upload_btn.pack(pady=10)
        
        # List of uploaded files
        self.files_listbox = tk.Listbox(
            self.window,
            width=60,
            height=10
        )
        self.files_listbox.pack(pady=10)
        
        # Remove selected file button
        remove_btn = tk.Button(
            self.window,
            text="Remove Selected",
            command=self._remove_selected,
            width=20,
            height=2
        )
        remove_btn.pack(pady=10)
        
        # Clear all button
        clear_btn = tk.Button(
            self.window,
            text="Clear All",
            command=self._clear_all,
            width=20,
            height=2
        )
        clear_btn.pack(pady=10)
        
        # Done button
        done_btn = tk.Button(
            self.window,
            text="Done",
            command=self._close,
            width=20,
            height=2
        )
        done_btn.pack(pady=10)
        
        # Update file list
        self._update_file_list()
    
    def _upload_files(self):
        """Handle file upload."""
        files = filedialog.askopenfilenames(
            title="Select PDF Files",
            filetypes=[("PDF files", "*.pdf")]
        )
        
        if files:
            for file_path in files:
                try:
                    # Copy file to upload directory
                    filename = os.path.basename(file_path)
                    dest_path = os.path.join(self.upload_dir, filename)
                    shutil.copy2(file_path, dest_path)
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to upload {filename}: {str(e)}")
            
            self._update_file_list()
            messagebox.showinfo("Success", f"Uploaded {len(files)} file(s)")
    
    def _remove_selected(self):
        """Remove selected file."""
        selection = self.files_listbox.curselection()
        if selection:
            filename = self.files_listbox.get(selection[0])
            try:
                os.remove(os.path.join(self.upload_dir, filename))
                self._update_file_list()
                messagebox.showinfo("Success", f"Removed {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to remove {filename}: {str(e)}")
    
    def _clear_all(self):
        """Clear all uploaded files."""
        if messagebox.askyesno("Confirm", "Are you sure you want to remove all files?"):
            try:
                for filename in os.listdir(self.upload_dir):
                    os.remove(os.path.join(self.upload_dir, filename))
                self._update_file_list()
                messagebox.showinfo("Success", "Removed all files")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to clear files: {str(e)}")
    
    def _update_file_list(self):
        """Update the list of uploaded files."""
        self.files_listbox.delete(0, tk.END)
        for filename in os.listdir(self.upload_dir):
            if filename.endswith('.pdf'):
                self.files_listbox.insert(tk.END, filename)
    
    def _close(self):
        """Close the window."""
        self.window.destroy()
    
    def run(self):
        """Run the GUI."""
        self.window.mainloop() 