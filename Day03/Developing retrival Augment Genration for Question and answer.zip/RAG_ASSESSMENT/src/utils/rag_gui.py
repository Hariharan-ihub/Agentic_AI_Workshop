import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import os
from typing import Optional
from src.preprocessing.pdf_processor import PDFProcessor
from src.preprocessing.embedding_generator import EmbeddingGenerator
from src.preprocessing.vector_db_manager import VectorDBManager

class RAGGUI:
    def __init__(self):
        """Initialize the RAG GUI application."""
        self.window = tk.Tk()
        self.window.title("RAG System")
        self.window.geometry("800x600")
        
        # Initialize components
        self.pdf_processor = PDFProcessor()
        self.embedding_generator = EmbeddingGenerator()
        self.vector_db = VectorDBManager(db_type="chroma")
        
        # Create necessary directories
        os.makedirs("data/uploads", exist_ok=True)
        os.makedirs("data/processed", exist_ok=True)
        os.makedirs("data/embeddings", exist_ok=True)
        
        self._create_widgets()
    
    def _create_widgets(self):
        """Create GUI widgets."""
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.window)
        self.notebook.pack(expand=True, fill='both', padx=10, pady=5)
        
        # File Upload Tab
        self.upload_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.upload_frame, text="Upload Files")
        self._create_upload_widgets()
        
        # Question Answering Tab
        self.qa_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.qa_frame, text="Ask Questions")
        self._create_qa_widgets()
    
    def _create_upload_widgets(self):
        """Create widgets for file upload tab."""
        # Title
        title_label = ttk.Label(
            self.upload_frame,
            text="Upload Research Papers",
            font=("Arial", 16, "bold")
        )
        title_label.pack(pady=20)
        
        # Upload button
        upload_btn = ttk.Button(
            self.upload_frame,
            text="Select PDF Files",
            command=self._upload_files
        )
        upload_btn.pack(pady=10)
        
        # List of uploaded files
        self.files_listbox = tk.Listbox(
            self.upload_frame,
            width=60,
            height=10
        )
        self.files_listbox.pack(pady=10)
        
        # Remove selected file button
        remove_btn = ttk.Button(
            self.upload_frame,
            text="Remove Selected",
            command=self._remove_selected
        )
        remove_btn.pack(pady=10)
        
        # Clear all button
        clear_btn = ttk.Button(
            self.upload_frame,
            text="Clear All",
            command=self._clear_all
        )
        clear_btn.pack(pady=10)
        
        # Status label
        self.status_label = ttk.Label(
            self.upload_frame,
            text="Ready to upload files",
            font=("Arial", 10)
        )
        self.status_label.pack(pady=10)
        
        # Update file list
        self._update_file_list()
    
    def _create_qa_widgets(self):
        """Create widgets for question answering tab."""
        # Question input
        question_label = ttk.Label(
            self.qa_frame,
            text="Enter your question:",
            font=("Arial", 12)
        )
        question_label.pack(pady=10)
        
        self.question_entry = ttk.Entry(
            self.qa_frame,
            width=60
        )
        self.question_entry.pack(pady=5)
        
        # Ask button
        ask_btn = ttk.Button(
            self.qa_frame,
            text="Ask",
            command=self._ask_question
        )
        ask_btn.pack(pady=10)
        
        # Answer display
        answer_label = ttk.Label(
            self.qa_frame,
            text="Answer:",
            font=("Arial", 12)
        )
        answer_label.pack(pady=10)
        
        self.answer_text = scrolledtext.ScrolledText(
            self.qa_frame,
            width=70,
            height=15,
            wrap=tk.WORD
        )
        self.answer_text.pack(pady=10)
    
    def _upload_files(self):
        """Handle file upload."""
        from tkinter import filedialog
        files = filedialog.askopenfilenames(
            title="Select PDF Files",
            filetypes=[("PDF files", "*.pdf")]
        )
        
        if files:
            try:
                for file_path in files:
                    # Copy file to upload directory
                    filename = os.path.basename(file_path)
                    dest_path = os.path.join("data/uploads", filename)
                    with open(file_path, 'rb') as src, open(dest_path, 'wb') as dst:
                        dst.write(src.read())
                
                self._update_file_list()
                self._process_documents()
                messagebox.showinfo("Success", f"Uploaded and processed {len(files)} file(s)")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to upload files: {str(e)}")
    
    def _process_documents(self):
        """Process uploaded documents."""
        upload_dir = "data/uploads"
        pdf_files = [f for f in os.listdir(upload_dir) if f.endswith('.pdf')]
        
        if not pdf_files:
            return
        
        self.status_label.config(text="Processing documents...")
        self.window.update()
        
        try:
            for pdf_file in pdf_files:
                # Process PDF
                pdf_path = os.path.join(upload_dir, pdf_file)
                pages = self.pdf_processor.load_pdf(pdf_path)
                chunks = self.pdf_processor.chunk_text(pages)
                
                # Generate embeddings
                embedding_result = self.embedding_generator.generate_embeddings(chunks)
                embeddings = embedding_result["embeddings"]
                
                # Add to vector database
                self.vector_db.add_documents(chunks, embeddings)
            
            self.status_label.config(text="Documents processed successfully!")
        except Exception as e:
            self.status_label.config(text=f"Error processing documents: {str(e)}")
    
    def _remove_selected(self):
        """Remove selected file."""
        selection = self.files_listbox.curselection()
        if selection:
            filename = self.files_listbox.get(selection[0])
            try:
                os.remove(os.path.join("data/uploads", filename))
                self._update_file_list()
                messagebox.showinfo("Success", f"Removed {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to remove {filename}: {str(e)}")
    
    def _clear_all(self):
        """Clear all uploaded files."""
        if messagebox.askyesno("Confirm", "Are you sure you want to remove all files?"):
            try:
                for filename in os.listdir("data/uploads"):
                    os.remove(os.path.join("data/uploads", filename))
                self._update_file_list()
                messagebox.showinfo("Success", "Removed all files")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to clear files: {str(e)}")
    
    def _update_file_list(self):
        """Update the list of uploaded files."""
        self.files_listbox.delete(0, tk.END)
        for filename in os.listdir("data/uploads"):
            if filename.endswith('.pdf'):
                self.files_listbox.insert(tk.END, filename)
    
    def _ask_question(self):
        """Handle question asking."""
        question = self.question_entry.get().strip()
        if not question:
            messagebox.showwarning("Warning", "Please enter a question")
            return
        
        try:
            # Generate embedding for the question
            question_embedding = self.embedding_generator.generate_embedding(question)
            
            # Search for relevant documents
            relevant_docs = self.vector_db.search(question_embedding)
            
            # Generate answer
            answer = self.embedding_generator.generate_answer(question, relevant_docs)
            
            # Display answer
            self.answer_text.delete(1.0, tk.END)
            self.answer_text.insert(tk.END, answer)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate answer: {str(e)}")
    
    def run(self):
        """Run the GUI application."""
        self.window.mainloop() 