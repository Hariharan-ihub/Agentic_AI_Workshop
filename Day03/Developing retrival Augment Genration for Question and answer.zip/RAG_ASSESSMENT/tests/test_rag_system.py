import os
import pytest
from src.preprocessing.pdf_processor import PDFProcessor, DocumentChunk
from src.preprocessing.embedding_generator import EmbeddingGenerator
from src.preprocessing.vector_db_manager import VectorDBManager
from src.retrieval.retriever import Retriever
from src.generation.answer_generator import AnswerGenerator
from src.config import (
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    EMBEDDING_MODEL,
    VECTOR_DB_TYPE,
    COLLECTION_NAME
)

@pytest.fixture
def pdf_processor():
    return PDFProcessor(chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP)

@pytest.fixture
def embedding_generator():
    return EmbeddingGenerator(model_name=EMBEDDING_MODEL)

@pytest.fixture
def vector_db():
    return VectorDBManager(db_type=VECTOR_DB_TYPE, collection_name=COLLECTION_NAME)

@pytest.fixture
def retriever(embedding_generator, vector_db):
    return Retriever(embedding_generator, vector_db)

@pytest.fixture
def answer_generator():
    return AnswerGenerator()

def test_pdf_processor(pdf_processor):
    # Test chunking
    test_text = "This is a test document. " * 100
    test_metadata = {"source": "test.pdf", "page": 1, "total_pages": 1}
    
    chunks = pdf_processor.chunk_text([{"text": test_text, "metadata": test_metadata}])
    
    assert len(chunks) > 0
    assert all(isinstance(chunk, DocumentChunk) for chunk in chunks)
    assert all(len(chunk.text) <= CHUNK_SIZE for chunk in chunks)

def test_embedding_generator(embedding_generator):
    # Test embedding generation
    test_text = "This is a test document."
    embedding = embedding_generator.generate_embedding(test_text)
    
    assert embedding.shape[0] > 0
    assert isinstance(embedding, type(embedding_generator.model.encode("test")))

def test_vector_db(vector_db):
    # Test vector database operations
    test_chunks = [
        DocumentChunk(
            text="Test document 1",
            metadata={"source": "test1.pdf", "page": 1},
            chunk_id="test1_0"
        ),
        DocumentChunk(
            text="Test document 2",
            metadata={"source": "test2.pdf", "page": 1},
            chunk_id="test2_0"
        )
    ]
    
    test_embeddings = [
        [0.1, 0.2, 0.3],
        [0.4, 0.5, 0.6]
    ]
    
    vector_db.add_documents(test_chunks, test_embeddings)
    
    # Test search
    query_embedding = [0.2, 0.3, 0.4]
    results = vector_db.search(query_embedding, k=1)
    
    assert len(results) == 1
    assert "text" in results[0]
    assert "metadata" in results[0]
    assert "distance" in results[0]

def test_retriever(retriever):
    # Test retrieval
    query = "What is a test document?"
    results = retriever.retrieve(query)
    
    assert isinstance(results, list)
    if len(results) > 0:
        assert "text" in results[0]
        assert "metadata" in results[0]
        assert "distance" in results[0]

def test_answer_generator(answer_generator):
    # Test answer generation
    query = "What is a test document?"
    context = [
        {
            "text": "This is a test document about testing.",
            "metadata": {"source": "test.pdf", "page": 1}
        }
    ]
    
    result = answer_generator.generate_answer(query, context)
    
    assert "answer" in result
    assert "sources" in result
    assert isinstance(result["answer"], str)
    assert isinstance(result["sources"], list)

def test_full_pipeline(pdf_processor, embedding_generator, vector_db, retriever, answer_generator):
    # Test full pipeline
    test_text = "This is a test document about testing. " * 10
    test_metadata = {"source": "test.pdf", "page": 1, "total_pages": 1}
    
    # Process document
    chunks = pdf_processor.chunk_text([{"text": test_text, "metadata": test_metadata}])
    embedding_data = embedding_generator.generate_embeddings(chunks)
    vector_db.add_documents(chunks, embedding_data["embeddings"])
    
    # Query
    query = "What is this document about?"
    retrieved_docs = retriever.retrieve(query)
    answer_result = answer_generator.generate_answer(query, retrieved_docs)
    
    assert isinstance(answer_result["answer"], str)
    assert len(answer_result["sources"]) > 0 