# RAG-based Question Answering System

This project implements a Retrieval-Augmented Generation (RAG) system for answering questions about AI research papers. The system processes PDF documents, creates vector embeddings, and uses them to generate accurate, context-aware answers to user queries.

## Features

- PDF document processing and chunking
- Vector embedding generation using sentence-transformers
- Vector storage using FAISS/ChromaDB
- Semantic search retrieval
- Context-aware answer generation using GPT-4
- Source attribution and citation
- Evaluation test suite

## Project Structure

```
.
├── data/                   # Directory for PDF documents
├── src/
│   ├── preprocessing/      # Document processing modules
│   ├── retrieval/         # Retrieval system components
│   ├── generation/        # Answer generation modules
│   ├── evaluation/        # Test suite and evaluation
│   └── utils/            # Utility functions
├── tests/                 # Test files
├── config.py             # Configuration settings
├── requirements.txt      # Project dependencies
└── README.md            # Project documentation
```

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Create a `.env` file with your OpenAI API key:
```
OPENAI_API_KEY=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
```

## Usage

1. Place your PDF documents in the `data/` directory
2. Run the preprocessing pipeline:
```bash
python src/preprocessing/process_documents.py
```

3. Start the question answering system:
```bash
python src/main.py
```

## Testing

Run the test suite:
```bash
pytest tests/
```

## License

MIT License 